<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
    <title> Title </title>
</head>
<body>

<form action="save-person.php" method="post">
    <fieldset>
        <label for="name">Name:</label>
        <input name="name" id="name" />
    </fieldset>
    <fieldset>
        <label for="email">Email:</label>
        <input name="email" id="email" />
    </fieldset>
    <button>Submit</button>     //submit button must be inside form tag
</form>
</body>
</html>